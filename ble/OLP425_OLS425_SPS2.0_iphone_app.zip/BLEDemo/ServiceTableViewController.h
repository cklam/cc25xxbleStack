//
//  ServiceTableViewController.h
//  BLEDemo
//
//  Created by Tomas Henriksson on 12/16/11.
//  Copyright (c) 2011 connectBlue. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreBluetooth/CBPeripheral.h>

@interface ServiceTableViewController : UITableViewController <CBPeripheralDelegate>

- (IBAction)serviceRefresh:(id)sender;

- (void) initWithPeripherals: (NSMutableArray*) discoveredPeripherals;

/*

- (void)peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error;

- (void)peripheral:(CBPeripheral *)peripheral didDiscoverServices:(NSError *)error;

- (void)peripheral:(CBPeripheral *)peripheral didDiscoverDescriptorsForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error;

- (void)peripheral:(CBPeripheral *)peripheral didDiscoverIncludedServicesForService:(CBService *)service error:(NSError *)error;

- (void)peripheral:(CBPeripheral *)peripheral didUpdateNotificationStateForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error;

- (void)peripheral:(CBPeripheral *)peripheral didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error;

- (void)peripheral:(CBPeripheral *)peripheral didUpdateValueForDescriptor:(CBDescriptor *)descriptor error:(NSError *)error;

- (void)peripheral:(CBPeripheral *)peripheral didWriteValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error;

- (void)peripheral:(CBPeripheral *)peripheral didWriteValueForDescriptor:(CBDescriptor *)descriptor error:(NSError *)error;

- (void)peripheralDidUpdateRSSI:(CBPeripheral *)peripheral error:(NSError *)error;
 */

- (void) refresh;

@end
