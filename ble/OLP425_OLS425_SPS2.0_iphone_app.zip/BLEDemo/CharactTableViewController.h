//
//  CharactTableViewController.h
//  BLEDemo
//
//  Created by Tomas Henriksson on 1/19/12.
//  Copyright (c) 2012 connectBlue. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <CoreBluetooth/CBPeripheral.h>
#import <CoreBluetooth/CBService.h>

@interface CharactTableViewController : UITableViewController <CBPeripheralDelegate>

@property (nonatomic, weak) CBPeripheral*     peripheral;
@property (nonatomic, weak) CBService*        service;
- (IBAction)refresh:(id)sender;

@end
