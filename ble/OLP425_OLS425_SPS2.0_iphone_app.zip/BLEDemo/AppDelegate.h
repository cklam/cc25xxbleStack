//
//  AppDelegate.h
//  BLEDemo
//
//  Created by Tomas Henriksson on 12/14/11.
//  Copyright (c) 2011 connectBlue. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
