//
//  ViewController.h
//  BLEDemo
//
//  Created by Tomas Henriksson on 12/14/11.
//  Copyright (c) 2011 connectBlue. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
