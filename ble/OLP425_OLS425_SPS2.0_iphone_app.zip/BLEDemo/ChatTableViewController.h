//
//  ChatTableViewController.h
//  BLEDemo
//
//  Created by Tomas Henriksson on 1/4/12.
//  Copyright (c) 2012 connectBlue. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SerialPort.h"

@interface ChatTableViewController : UITableViewController <UITextFieldDelegate, SerialPortDelegate>

@property (strong, nonatomic) IBOutlet UITextField *messageTextField;

- (void) initWithPeripherals: (NSMutableArray*) discoveredPeripherals;

- (IBAction)sendMessage:(id)sender;

@end
